//to make student grade calc
import java.util.*;
public class studentgrade022{

    public void main()
    {
        
        System.out.println("enter your marks in 7 subjects" );//input of 7 subjects marks
        Scanner sc = new Scanner(System.in);
        int a[]=new int[7];
        for(int i=0;i<=6;i++)
        {
            a[i]=sc.nextInt();
        }
        int sum =0;
       
        
            for(int n=0;n<=6;n++)
            { sum=sum+a[n];}
            double studentavg=0.0;
            studentavg=sum/7.0;
            System.out.println("Total marks scored out of 700 is"+ sum);//sum of 7 subjects
            System.out.println("average precentage of the student is" + studentavg);//avg percentage of 7 marks
            if(studentavg>=95)
            System.out.println("THE GRADE RECIEVED IS O:OUTSTANDING");
            else if(studentavg<95 && studentavg>=90)
            System.out.println("THE GRADE RECIEVED IS A+:EXCELLENT");
            else if (studentavg<90 && studentavg>=85)
            System.out.println("THE GRADE RECIEVED IS A : VERY GOOD");
            else if (studentavg<85 && studentavg>=80)
            System.out.println("THE GRADE RECIEVED IS B+ : GOOD");
            else if (studentavg<80 && studentavg>=70)
            System.out.println("THE GRADE RECIEVED IS B : ABOVE AVERAGE");
            else if (studentavg<70 && studentavg>=60)
            System.out.println("THE GRADE RECIEVED IS C: AVERAGE");
            else if (studentavg>=50 && studentavg<60)
            System.out.println("THE STUDENT IS PASSED : GRADE P");
            else
            System.out.println("THE STUDENT IS FAILED : GRADE F");
        }}
            