
import java.util.Scanner;

public class numbergame {
    private int randomno;
    
    public numbergame() {
        // Generate random number once per game
        randomno = (int) (Math.random() * 100);
    }
    
    public void guess(int maxAtt) {
        Scanner sc = new Scanner(System.in);
        int attempts = 0;
        
        while (attempts < maxAtt) {
            System.out.println("Enter the number you want to guess ");
            int guess = sc.nextInt();
            attempts++;
            
            if (guess < randomno) {
                System.out.println("The number you have guesed is too low......please try again");
            } else if (guess > randomno) {
                System.out.println("The number you have guessed is tooo high.....please try again");
            }  else{
                    System.out.println("you have guessed the correct number right in " + attempts + " attempts!");
                return;
            }
            
            System.out.println("Attempts left: " + (maxAtt - attempts));
        }
        
        System.out.println("Sorry, you couldn't guess the number (" + randomno + ").");
    }
    
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to the Number Game Challenge!");
        
        while (true) {
            System.out.println("Enter the mode you want to play the guess game:");
            System.out.println("Enter choice\n1. To play easy mode \n2. To play medium mode \n3. To play hard mode \n4. To exit");
            
            int ch = sc.nextInt();
            
            switch (ch) {
                case 1:
                    System.out.println("Easy mode selected. You have 12 attempts.");
                    new numbergame().guess(12);
                    break;
                case 2:
                    System.out.println("Medium mode selected. You have 8 attempts.");
                    new numbergame().guess(8);
                    break;
                case 3:
                    System.out.println("Hard mode selected. You have 4 attempts.");
                    new numbergame().guess(4);
                    break;
                case 4:
                    System.out.println("Thank you for playing the guess game");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.Please try again");
            }
        }
    }
}


