
import java.util.Scanner;

class SavingsAccount extends ATM {
    double interestRate;

    public SavingsAccount(String acc, double bal, double interestRate) {
        super(acc, bal); 
        this.interestRate = interestRate;
    }

    public void addInterest() {
        double interest = balance * interestRate / 100;
        balance += interest;
        System.out.println("Interest added. New balance: " + balance);
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter account number :");
        String acc = sc.nextLine();
        System.out.println("Enter balance :");
        double bal = sc.nextDouble();
        System.out.println("Enter interest rate :");
        double interestRate = sc.nextDouble();

        SavingsAccount account = new SavingsAccount(acc, bal, interestRate);
        account.addInterest();
        System.out.println("Enter amount to be deposited :");
        double d=sc.nextDouble();
        account.deposit(d);
        account.getBalance();
        System.out.println("Enter amount to be withdrawn :");
        double w =sc.nextDouble();
        account.getBalance();
        
        
        
    }
}