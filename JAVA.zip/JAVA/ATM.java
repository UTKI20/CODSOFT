import java.util.*;
public class ATM
 {
    String accountNumber;
    double balance;
    public ATM(String accountNumber, double balance) 
    {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public void deposit(double amount) 
    {
        balance += amount;
        System.out.println(amount + " deposited. New balance: " + balance);
    }

    public void withdraw(double amount)
    {
        if (amount <= balance) 
        {
            balance -= amount;
            System.out.println(amount + " withdrawn. New balance: " + balance);
        } 
        else 
            System.out.println("Insufficient funds");
        
    }

    public double getBalance()
    {
        return balance;
    }
}
